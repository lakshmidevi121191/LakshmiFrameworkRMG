package SelFunctions;

public class seleniumWebProg {

public void webBrowser() 
{
	
}
}
